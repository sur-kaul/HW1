﻿using System;
using System.Collections.Generic;
class Program
{
    static void DisplayMenu()
    {
        Console.WriteLine("Menu");
        Console.WriteLine("1 - Burger $10.99");
        Console.WriteLine("2 - Chicken Sandwich $9.99");
        Console.WriteLine("3 - Salad $8.49");
        Console.WriteLine("4 - Fries $3.49");
        Console.WriteLine("5 - Drink $2.49");
        Console.WriteLine("0 - Finished Ordering");
    }

    static void AddItem(List<string> order, int choice)
    {
        if (choice == 1)
        {
            order.Add("Burger");
        }
        else if (choice == 2)
        {
            order.Add("Chicken Sandwich");
        }
        else if (choice == 3)
        {
            order.Add("Salad");
        }
        else if (choice == 4)
        {
            order.Add("Fries");
        }
        else if (choice == 5)
        {
            order.Add("Drink");
        }
        else
        {
            Console.WriteLine("Invalid selection.");
        }
    }

    static decimal CalculateSubtotal(List<string> order)
    {
        decimal subtotal = 0;

        foreach (string item in order)
        {
            if (item == "Burger")
            {
                subtotal = subtotal + 10.99m;
            }
            else if (item == "Chicken Sandwich")
            {
                subtotal = subtotal + 9.99m;
            }
            else if (item == "Salad")
            {
                subtotal = subtotal + 8.49m;
            }
            else if (item == "Fries")
            {
                subtotal = subtotal + 3.49m;
            }
            else if (item == "Drink")
            {
                subtotal = subtotal + 2.49m;
            }
        }

        return subtotal;
    }

    static decimal CalculateFinalTotal(decimal subtotal)
    {
        decimal discount = 0;
        decimal tax;
        decimal total;

        if (subtotal >= 30)
        {
            discount = subtotal * 0.10m;
        }

        decimal afterDiscount = subtotal - discount;
        tax = afterDiscount * 0.085m;
        total = afterDiscount + tax;

        return total;
    }

    static void Main()
    {
        List<string> order = new List<string>();

        int choice = -1;

        while (choice != 0)
        {
            Console.WriteLine();
            DisplayMenu();

            Console.Write("Enter your choice: ");
            choice = Convert.ToInt32(Console.ReadLine());

            if (choice != 0)
            {
                AddItem(order, choice);
            }
        }

        decimal subtotal = CalculateSubtotal(order);

        decimal discount = 0;

        if (subtotal >= 30)
        {
            discount = subtotal * 0.10m;
        }

        decimal afterDiscount = subtotal - discount;
        decimal tax = afterDiscount * 0.085m;
        decimal total = CalculateFinalTotal(subtotal);

        Console.WriteLine();
        Console.WriteLine("Order Summary");
        Console.WriteLine("--------------------");

        Console.WriteLine("Items ordered:");

        foreach (string item in order)
        {
            Console.WriteLine(item);
        }

        Console.WriteLine("Subtotal: $" + subtotal.ToString("F2"));
        Console.WriteLine("Discount: $" + discount.ToString("F2"));
        Console.WriteLine("Tax: $" + tax.ToString("F2"));
        Console.WriteLine("Final total: $" + total.ToString("F2"));
    }
}
