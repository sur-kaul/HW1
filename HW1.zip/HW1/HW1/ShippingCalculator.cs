﻿using System;
class Program
{
    static decimal CalculateShipping(decimal subtotal, int method, char rewards)
    {
        decimal shipping = 0;

        if (method == 1)
        {
            if (subtotal >= 75)
            {
                shipping = 0;
            }
            else
            {
                shipping = 5.99m;
            }
        }
        else if (method == 2)
        {
            shipping = 12.99m;

            if (rewards == 'Y')
            {
                shipping = shipping * 0.80m;
            }
        }
        else if (method == 3)
        {
            shipping = 24.99m;

            if (rewards == 'Y')
            {
                shipping = shipping * 0.80m;
            }
        }

        return shipping;
    }

    static void Main()
    {
        decimal subtotal;
        int method;
        char rewards;

        Console.Write("Enter order subtotal: ");
        subtotal = Convert.ToDecimal(Console.ReadLine());

        Console.Write("Are you a rewards member? (Y/N): ");
        rewards = Convert.ToChar(Console.ReadLine());

        Console.WriteLine("1 - Standard");
        Console.WriteLine("2 - Two-Day");
        Console.WriteLine("3 - Overnight");

        Console.Write("Enter shipping method: ");
        method = Convert.ToInt32(Console.ReadLine());

        if (subtotal <= 0)
        {
            Console.WriteLine("Subtotal must be greater than 0.");
        }
        else if (method < 1 || method > 3)
        {
            Console.WriteLine("Invalid shipping method.");
        }
        else
        {
            decimal shipping = CalculateShipping(subtotal, method, rewards);
            decimal total = subtotal + shipping;

            Console.WriteLine();
            Console.WriteLine("Order subtotal: $" + subtotal);

            if (method == 1)
            {
                Console.WriteLine("Shipping method: Standard");
            }
            else if (method == 2)
            {
                Console.WriteLine("Shipping method: Two-Day");
            }
            else
            {
                Console.WriteLine("Shipping method: Overnight");
            }

            Console.WriteLine("Shipping cost: $" + shipping);
            Console.WriteLine("Final order total: $" + total);
        }
    }
}