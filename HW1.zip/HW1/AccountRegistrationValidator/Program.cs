﻿using System;
class Program
{
    static bool IsValidEmail(string email)
    {
        if (email.Length >= 6 && email.Contains("@") && email.Contains("."))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static bool IsValidPassword(string password)
    {
        bool hasUppercase = false;
        bool hasNumber = false;

        if (password.Length < 8)
        {
            return false;
        }

        foreach (char letter in password)
        {
            if (char.IsUpper(letter))
            {
                hasUppercase = true;
            }

            if (char.IsNumber(letter))
            {
                hasNumber = true;
            }
        }

        if (hasUppercase && hasNumber)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static bool IsValidAge(int age)
    {
        if (age >= 18)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static void Main()
    {
        Console.Write("Enter first name: ");
        string firstName = Console.ReadLine();

        Console.Write("Enter last name: ");
        string lastName = Console.ReadLine();

        Console.Write("Enter email address: ");
        string email = Console.ReadLine();

        Console.Write("Enter password: ");
        string password = Console.ReadLine();

        Console.Write("Confirm password: ");
        string confirmPassword = Console.ReadLine();

        Console.Write("Enter age: ");
        int age = Convert.ToInt32(Console.ReadLine());

        bool valid = true;

        Console.WriteLine();

        if (firstName == "")
        {
            Console.WriteLine("- First name cannot be blank.");
            valid = false;
        }

        if (lastName == "")
        {
            Console.WriteLine("- Last name cannot be blank.");
            valid = false;
        }

        if (!IsValidEmail(email))
        {
            Console.WriteLine("- Email address is invalid.");
            valid = false;
        }

        if (!IsValidPassword(password))
        {
            Console.WriteLine("- Password is invalid.");

            if (password.Length < 8)
            {
                Console.WriteLine("- Password must be at least 8 characters long.");
            }

            bool hasUppercase = false;
            bool hasNumber = false;

            foreach (char letter in password)
            {
                if (char.IsUpper(letter))
                {
                    hasUppercase = true;
                }

                if (char.IsNumber(letter))
                {
                    hasNumber = true;
                }
            }

            if (!hasUppercase)
            {
                Console.WriteLine("- Password must contain an uppercase letter.");
            }

            if (!hasNumber)
            {
                Console.WriteLine("- Password must contain a number.");
            }

            valid = false;
        }

        if (password != confirmPassword)
        {
            Console.WriteLine("- Passwords do not match.");
            valid = false;
        }

        if (!IsValidAge(age))
        {
            Console.WriteLine("- You must be at least 18 years old.");
            valid = false;
        }

        if (valid)
        {
            Console.WriteLine("Account Successfully Created!");
            Console.WriteLine();
            Console.WriteLine("Welcome, " + firstName + " " + lastName + "!");
        }
        else
        {
            Console.WriteLine();
            Console.WriteLine("Registration Failed");
        }
    }
}
