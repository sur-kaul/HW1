﻿using System;
using System.Collections.Generic;
class Product
{
    public string ProductName;
    public string Category;
    public decimal Price;
    public bool InStock;
}

class Program
{
    static void DisplayProducts(List<Product> products)
    {
        foreach (Product product in products)
        {
            Console.WriteLine(product.ProductName + " - " + product.Category + " - $" + product.Price + " - In Stock: " + product.InStock);
        }
    }

    static void SearchProducts(List<Product> products, string name)
    {
        bool found = false;

        foreach (Product product in products)
        {
            if (product.ProductName.ToLower().Contains(name.ToLower()))
            {
                Console.WriteLine(product.ProductName + " - " + product.Category + " - $" + product.Price + " - In Stock: " + product.InStock);

                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("No products found.");
        }
    }

    static void FilterByCategory(List<Product> products, string category)
    {
        bool found = false;

        foreach (Product product in products)
        {
            if (product.Category.ToLower() == category.ToLower())
            {
                Console.WriteLine(product.ProductName + " - " + product.Category + " - $" + product.Price + " - In Stock: " + product.InStock);

                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("No products found in that category.");
        }
    }

    static void FilterByPrice(List<Product> products, decimal maxPrice)
    {
        bool found = false;

        foreach (Product product in products)
        {
            if (product.Price <= maxPrice)
            {
                Console.WriteLine(product.ProductName + " - " + product.Category + " - $" + product.Price + " - In Stock: " + product.InStock);

                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("No products found at that price or less.");
        }
    }

    static void ShowInStock(List<Product> products)
    {
        bool found = false;

        foreach (Product product in products)
        {
            if (product.InStock == true)
            {
                Console.WriteLine(product.ProductName + " - " + product.Category + " - $" + product.Price + " - In Stock: " + product.InStock);

                found = true;
            }
        }

        if (!found)
        {
            Console.WriteLine("No products are currently in stock.");
        }
    }

    static void Main()
    {
        List<Product> products = new List<Product>();

        products.Add(new Product { ProductName = "Laptop", Category = "Electronics", Price = 899.99m, InStock = true });
        products.Add(new Product { ProductName = "Headphones", Category = "Electronics", Price = 59.99m, InStock = true });
        products.Add(new Product { ProductName = "Keyboard", Category = "Electronics", Price = 39.99m, InStock = false });
        products.Add(new Product { ProductName = "T-Shirt", Category = "Clothing", Price = 19.99m, InStock = true });
        products.Add(new Product { ProductName = "Jeans", Category = "Clothing", Price = 49.99m, InStock = true });
        products.Add(new Product { ProductName = "Jacket", Category = "Clothing", Price = 79.99m, InStock = false });
        products.Add(new Product { ProductName = "Coffee Maker", Category = "Home", Price = 69.99m, InStock = true });
        products.Add(new Product { ProductName = "Lamp", Category = "Home", Price = 29.99m, InStock = true });
        products.Add(new Product { ProductName = "Blender", Category = "Home", Price = 44.99m, InStock = false });
        products.Add(new Product { ProductName = "Backpack", Category = "Accessories", Price = 34.99m, InStock = true });

        int choice = 0;

        while (choice != 6)
        {
            Console.WriteLine();
            Console.WriteLine("Product Menu");
            Console.WriteLine("1 - View all products");
            Console.WriteLine("2 - Search products by name");
            Console.WriteLine("3 - Filter by category");
            Console.WriteLine("4 - Filter by maximum price");
            Console.WriteLine("5 - Show products in stock");
            Console.WriteLine("6 - Exit");

            Console.Write("Enter your choice: ");
            choice = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            if (choice == 1)
            {
                DisplayProducts(products);
            }
            else if (choice == 2)
            {
                Console.Write("Enter product name: ");
                string name = Console.ReadLine();

                SearchProducts(products, name);
            }
            else if (choice == 3)
            {
                Console.Write("Enter category: ");
                string category = Console.ReadLine();

                FilterByCategory(products, category);
            }
            else if (choice == 4)
            {
                Console.Write("Enter maximum price: $");
                decimal maxPrice = Convert.ToDecimal(Console.ReadLine());

                FilterByPrice(products, maxPrice);
            }
            else if (choice == 5)
            {
                ShowInStock(products);
            }
            else if (choice == 6)
            {
                Console.WriteLine("Goodbye!");
            }
            else
            {
                Console.WriteLine("Invalid choice.");
            }
        }
    }
}